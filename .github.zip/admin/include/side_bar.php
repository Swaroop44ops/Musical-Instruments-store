<div class="col-md-2 sidebar" style="margin-left:20px">
  			<div class="row">
	<div class="absolute-wrapper"> </div>
	<!-- Menu -->
	<div class="side-menu">
		<nav class="navbar navbar-default" role="navigation">
			<!-- Main Menu -->
			<div class="side-menu-container">
			  <ul class="nav navbar-nav">
<li><button style="width:240px; height:50px" type="button" class="btn btn-default btn-primary" onClick="location.href='index.php'"><span class="glyphicon  glyphicon-home pull-left"></span> DASHBOARD </button></li> 
  <li><button style="width:240px; height:50px" type="button" class="btn btn-default btn-success" onClick="location.href='orders.php'"> <span class="glyphicon glyphicon-edit pull-left"></span> ORDERS </button></li>
  
  <li><button style="width:240px; height:50px" type="button" class="btn btn-default btn-primary" onClick="location.href='add_product.php'"> <span class="glyphicon glyphicon-edit pull-left"></span> ADD PRODUCTS </button></li>
  <li>
  <button style="width:240px; height:50px" type="button" class="btn btn-default dropdown-toggle btn-primary" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <span class="glyphicon glyphicon-edit pull-left"></span>  PRODUCTS LISTS <span class="glyphicon glyphicon-triangle-bottom pull-right"></span>
  </button>
  <ul class="dropdown-menu" style="width:240px">
    <li><a href="instruments_list.php"><strong>INSTRUMENTS LISTS</strong> </a></li>
 <li><a href="accessories_list.php"><strong> ACCESSORIES LISTS</strong></a></li>
   </ul></li>

 

<li><button style="width:240px; height:50px" type="button" class="btn btn-default btn-primary" onClick="location.href='manage_users.php'"> <span class="glyphicon glyphicon-edit pull-left"></span> MANAGE USERS</button></li>	
<li><button style="width:240px; height:50px" type="button" class="btn btn-default btn-danger" onClick="location.href='../logout.php'"><span class="glyphicon glyphicon-off pull-left">
</span> LOGOUT </button></li>
			  </ul>
		  </div>
		</nav>
        </div>
</div></div>